import { SkillsList } from './skills-list';

describe('SkillsList', () => {
  it('should create an instance', () => {
    expect(new SkillsList()).toBeTruthy();
  });
});
