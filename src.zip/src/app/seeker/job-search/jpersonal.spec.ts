import { Jpersonal } from './jpersonal';

describe('Jpersonal', () => {
  it('should create an instance', () => {
    expect(new Jpersonal()).toBeTruthy();
  });
});
