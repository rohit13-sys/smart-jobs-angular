// import { Job } from "./job";

// export const Jobs: Job[] = [
//     {
//       id:101,
//       companyName: "STL",
//       jobRole: "Front-end Developer",
//       skills: "Html,css,javacript,React-js",
//       jobType: "Permanent",
//       salary: 15000.00,
//       isActive: "Active",
//       exp: "0-1 Years"
//     },
//     {
//       id:102,
//       companyName: "Docomo",
//       jobRole: "Back-end Developer",
//       skills: "Java,Spring,hibernate",
//       jobType: "Internship",
//       salary: 5000.00,
//       isActive: "NotActive",
//       exp: "1-2 Years"
//     },
//     {
//       id:103,
//       companyName: "Sparks",
//       jobRole: "Full Stack Developer",
//       skills: "Html,css,javacript,React-js,Java,Database",
//       jobType: "Permanent",
//       salary: 25000.00,
//       isActive: "NotActive",
//       exp: "3-4 Years"
//     },
//     {  id:104,
//       companyName: "Sparks",
//       jobRole: "Angular Developer",
//       skills: "Html,css,javacript,Typescript",
//       jobType: "Permanent",
//       salary: 25000.00,
//       isActive: "NotActive",
//       exp: "0-1 Years"
//     },
//     {
//         id:105,
//       companyName: "SpceX",
//       jobRole: "Management",
//       skills: "Communication skills,English,French",
//       jobType: "Permanent",
//       salary: 35000.00,
//       isActive: "Active",
//       exp: "2-5 Months"
//     },
//     {
//         id:106,
//       companyName: "Tesla",
//       jobRole: "Front-end Developer",
//       skills: "Html,css,javacript,React-js",
//       jobType: "Contract",
//       salary: 25000.00,
//       isActive: "NotActive",
//       exp: "1-4 Years"
//     },
//     {
//         id:107,
//       companyName: "master",
//       jobRole: "HR Management",
//       skills: "Communication skills,English,Leadrship skills,Creativity",
//       jobType: "Permanent",
//       salary: 55000.00,
//       isActive: "Active",
//       exp: "2-5 Years"
//     }
//   ]