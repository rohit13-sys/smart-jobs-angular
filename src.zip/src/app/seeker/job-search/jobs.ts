export class Jobs {
    jobPostId:any=0
}
