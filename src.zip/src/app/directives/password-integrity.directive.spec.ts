import { PasswordIntegrityDirective } from './password-integrity.directive';

describe('PasswordIntegrityDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordIntegrityDirective();
    expect(directive).toBeTruthy();
  });
});
