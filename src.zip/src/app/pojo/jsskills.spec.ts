import { Jsskills } from './jsskills';

describe('Jsskills', () => {
  it('should create an instance', () => {
    expect(new Jsskills()).toBeTruthy();
  });
});
