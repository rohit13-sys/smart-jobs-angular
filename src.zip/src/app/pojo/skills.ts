export class Skills {
    skillId:number = 0
    skillName:string = ''
}
