export class Employee {
    sr_no!:number;
    login!:{
        userId:string;
        pwd:string;
        role:string;
    };
    seeker_name!:string;
    ph_no!:string;
}
