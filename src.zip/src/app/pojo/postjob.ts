export class Postjob {
}
