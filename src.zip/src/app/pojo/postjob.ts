export class Postjob {
}
