import { Jpersonal } from "../seeker/job-search/jpersonal"

export class Jsskills {
    skillName:string = ''
    sr_no:Jpersonal = new Jpersonal()
}
