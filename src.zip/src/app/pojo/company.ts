export class Company {
    companyName:string = ''
    establishmentDate:Date = new Date()
    companyWebsite:string = ''
}
