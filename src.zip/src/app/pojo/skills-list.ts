export const SkillsList:any = [
    { id:1,skillName:'HTML' },
    {id:2,skillName:'CSS' },
    {id:3,skillName:'JAVASCRIPT' },
    { id:4,skillName:'ANGULAR TS' },
    { id:5,skillName:'REACT JS' },
    {id:6,skillName: 'Problem-Solving Skills'},
    {id:7,skillName: 'c'},
    {id:8,skillName: 'c++'},
    {id:9,skillName: 'Java'},
    {id:10,skillName: 'Python'},
    {id:11,skillName: 'Linux'},
    {id:12,skillName: 'Technical Aptitude'},
    {id:13,skillName:'Interpersonal skills'},
    {id:14,skillName:'Communication and motivation'},
    {id:15,skillName:'Organisation and delegation'}
  ]
