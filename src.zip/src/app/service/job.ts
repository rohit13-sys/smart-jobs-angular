export class Job {
    id:number=0
    companyName:string=''
    jobRole: string=''
    jobType: string=''
    expRequired: number=0
}
