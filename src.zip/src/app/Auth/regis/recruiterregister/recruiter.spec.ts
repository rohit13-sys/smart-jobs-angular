import { Recruiter } from './recruiter';

describe('Recruiter', () => {
  it('should create an instance', () => {
    expect(new Recruiter()).toBeTruthy();
  });
});
