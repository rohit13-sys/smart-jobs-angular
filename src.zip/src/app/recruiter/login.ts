export class Login {
    userId:string = ''
    pwd:string = ''
    role:string = ''
}
