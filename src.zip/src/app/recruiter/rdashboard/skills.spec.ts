import { Skills } from './skills';

describe('Skills', () => {
  it('should create an instance', () => {
    expect(new Skills()).toBeTruthy();
  });
});
