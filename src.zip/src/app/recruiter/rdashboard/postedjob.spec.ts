import { Postedjob } from './postedjob';

describe('Postedjob', () => {
  it('should create an instance', () => {
    expect(new Postedjob()).toBeTruthy();
  });
});
