export class JobSeeker {
    seekerName: string = ''
    seekerMail: string = ''
    seekerMobile: string = ''
    seekerSkills: string = ''
    appliedFor: number = 0
    resume: string = "."
}
