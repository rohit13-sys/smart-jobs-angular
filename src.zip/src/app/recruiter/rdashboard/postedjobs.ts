import { Postedjob } from "./postedjob";

export const Postedjobs:Postedjob[] = [
        // {
        //   jobPostId: 1,
        //   companyName: "STL",
        //   jobRole: "Front-end Developer",
        //   skills: "Html,css,javacript,React-js",
        //   jobType: "Permanent",
        //   salary: 15000.00,
        //   isActive: "Active",
        //   exp: "0-1 Years"
        // },
        // {
        //   jobPostId: 2,
        //   companyName: "STL",
        //   jobRole: "Back-end Developer",
        //   skills: "Java,Spring,hibernate",
        //   jobType: "Internship",
        //   salary: 5000.00,
        //   isActive: "NotActive",
        //   exp: "1-2 Years"
        // },
        // {
        //   jobPostId: 3,
        //   companyName: "STL",
        //   jobRole: "Full Stack Developer",
        //   skills: "Html,css,javacript,React-js,Java,Database",
        //   jobType: "Permanent",
        //   salary: 25000.00,
        //   isActive: "NotActive",
        //   exp: "3-4 Years"
        // },
        // {
        //   jobPostId: 4,
        //   companyName: "STL",
        //   jobRole: "Angular Developer",
        //   skills: "Html,css,javacript,Typescript",
        //   jobType: "Permanent",
        //   salary: 25000.00,
        //   isActive: "NotActive",
        //   exp: "0-1 Years"
        // },
        // {
        //   jobPostId: 5,
        //   companyName: "STL",
        //   jobRole: "Management",
        //   skills: "Communication skills,English,French",
        //   jobType: "Permanent",
        //   salary: 35000.00,
        //   isActive: "Active",
        //   exp: "2-5 Months"
        // },
        // {
        //   jobPostId: 6,
        //   companyName: "STL",
        //   jobRole: "Front-end Developer",
        //   skills: "Html,css,javacript,React-js",
        //   jobType: "Contract",
        //   salary: 25000.00,
        //   isActive: "NotActive",
        //   exp: "1-4 Years"
        // },
        // {
        //   jobPostId: 7,
        //   companyName: "STL",
        //   jobRole: "HR Management",
        //   skills: "Communication skills,English,Leadrship skills,Creativity",
        //   jobType: "Permanent",
        //   salary: 55000.00,
        //   isActive: "Active",
        //   exp: "2-5 Years"
        // }    
] 