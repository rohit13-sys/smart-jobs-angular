import { JobSeekers } from './job-seekers';

describe('JobSeekers', () => {
  it('should create an instance', () => {
    expect(new JobSeekers()).toBeTruthy();
  });
});
