import { JobSeeker } from "src/app/pojo/job-seeker"

export const JobSeekers:JobSeeker[] = [
    // {
    //     seekerName: "John",
    //     seekerMail: "john@gmail.com",
    //     seekerMobile: "9200123423",
    //     seekerSkills: "Html,css,javacript",
    //     resume: "."
    // },
    // {
    //     seekerName: "John wick",
    //     seekerMail: "johnWick@gmail.com",
    //     seekerMobile: "9200123423",
    //     seekerSkills: "Html,css,javacript,java",
    //     resume: "."
    // },
    // {
    //     seekerName: "Kakarot",
    //     seekerMail: "kakrot@gmail.com",
    //     seekerMobile: "9234423423",
    //     seekerSkills: "java,javacript,nodeJs",
    //     resume: "."
    // },
    // {
    //     seekerName: "Meliodas",
    //     seekerMail: "Melodas@gmail.com",
    //     seekerMobile: "8123434233",
    //     seekerSkills: "Communication Skills,English,French",
    //     resume: "."
    // },
    // {
    //     seekerName: "Escanor",
    //     seekerMail: "Escanor@gmail.com",
    //     seekerMobile: "7823123423",
    //     seekerSkills: "Html,css,javacript,Angular,Typescript",
    //     resume: "."
    // },
    // {
    //     seekerName: "Light",
    //     seekerMail: "light@gmail.com",
    //     seekerMobile: "7988343423",
    //     seekerSkills: "Html,css,javacript",
    //     resume: "."
    // },
    // {
    //     seekerName: "Parth",
    //     seekerMail: "parth@gmail.com",
    //     seekerMobile: "9200123423",
    //     seekerSkills: "Html,css,javacript",
    //     resume: "."
    // }
]
