import { Postjob } from './postjob';

describe('Postjob', () => {
  it('should create an instance', () => {
    expect(new Postjob()).toBeTruthy();
  });
});
