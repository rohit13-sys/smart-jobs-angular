export class Company {
    companyName:string = ''
    establishmentDate:Date|undefined
    companyWebsite:string = ''
}
