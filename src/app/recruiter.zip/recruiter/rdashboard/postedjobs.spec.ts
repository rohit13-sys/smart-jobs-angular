import { Postedjobs } from './postedjobs';

describe('Postedjobs', () => {
  it('should create an instance', () => {
    expect(new Postedjobs()).toBeTruthy();
  });
});
