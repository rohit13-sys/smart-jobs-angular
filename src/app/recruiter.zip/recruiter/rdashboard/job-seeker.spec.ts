import { JobSeeker } from './job-seeker';

describe('JobSeeker', () => {
  it('should create an instance', () => {
    expect(new JobSeeker()).toBeTruthy();
  });
});
