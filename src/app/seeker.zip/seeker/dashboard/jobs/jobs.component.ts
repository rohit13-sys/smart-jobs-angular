import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {

  waitforjobs:any;
  appliedmessage:any;
  alreadyapplied:any;
  errormessage:any;
  totaljobs:any;
  headers=['Company Name','Job Role','Skills','Experience'];
  jobs:any=[
    {
      companyName:"Sterlite",
      jobRole:'Java developer',
      skills:'Java',
      expRequired:1-2
  },
  {
    companyName:"TCS",
    jobRole:'front-end developer',
    skills:'Angular',
    expRequired:0-1
  },
  {
    companyName:"Infosys",
    jobRole:'designer',
    skills:'photoshop',
    expRequired:2-5
  }
  ];
    constructor() { }
    ngOnInit() {
    this.getjobs();
    }
  
    getjobs()
    {
     
    }
    apply()
    {
        
    }

}
