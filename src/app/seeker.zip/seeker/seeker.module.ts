import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SeekerProfileComponent } from './seeker-profile/seeker-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    DashboardComponent,
    SeekerProfileComponent,
    EditProfileComponent,
    SearchComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports:[
    SeekerProfileComponent,
    EditProfileComponent,
    SearchComponent,
    DashboardComponent
  ]
})
export class SeekerModule { }
